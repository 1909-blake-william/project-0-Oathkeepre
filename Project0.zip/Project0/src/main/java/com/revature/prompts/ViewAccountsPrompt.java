package com.revature.prompts;

import com.revature.daos.DBConnectionDao;
import com.revature.daos.UserDao;

public class ViewAccountsPrompt implements Prompt
{
	DBConnectionDao dbDao = new DBConnectionDao();
	UserDao user = UserDao.currentImplementation;
	
	@Override
	public Prompt run() 
	{
		System.out.println("All Open Accounts");
		System.out.println();
		
		if (user.getRole().equals("User"))
		{
			dbDao.displayAllAccounts(user.getUserId());
			System.out.println();
			return new MainMenuPrompt();
		}
		else if (user.getRole().equals("Admin"))
		{
			dbDao.adminDisplayAllAccounts();
		}
		System.out.println();
		System.out.println("Press any button to leave");
		return new AdminPrompt();
	}
}
