package com.revature.prompts;

import java.util.Scanner;

import com.revature.daos.DBConnectionDao;

public class AdminPrompt implements Prompt
{
	private Scanner s = new Scanner(System.in);
	DBConnectionDao dbDao = new DBConnectionDao();
	
	public Prompt run()
	{
		System.out.println();
		System.out.println("Please choose an option");
		System.out.println("Enter 1 to view accounts");
		System.out.println("Enter 2 to view users"); // table = people
		System.out.println("Enter 3 to log out");
		System.out.print("Your option?: ");
		
		String selection = s.nextLine();
		System.out.println();
		
		switch(selection)
		{
		case "1":
			return new ViewAccountsPrompt();
		case "2":
			return new ViewUsersPrompt();
		case "3":
			return new LoginPrompt();
		}
		
		return null;
	}
}
