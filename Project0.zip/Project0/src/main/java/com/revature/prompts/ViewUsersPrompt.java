package com.revature.prompts;

import java.util.Scanner;

import com.revature.daos.DBConnectionDao;
import com.revature.daos.UserDao;

public class ViewUsersPrompt implements Prompt 
{

	DBConnectionDao dbDao = new DBConnectionDao();
	UserDao user = UserDao.currentImplementation;
	Scanner s = new Scanner(System.in);
	
	@Override
	public Prompt run()
	{
		System.out.println("All Active Users");
		System.out.println();
		
		dbDao.adminDisplayAllUsers();
		
		System.out.println();
		System.out.println("Press any button to leave");
		return new AdminPrompt();
	}
}
