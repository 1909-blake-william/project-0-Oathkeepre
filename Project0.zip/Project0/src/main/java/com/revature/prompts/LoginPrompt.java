package com.revature.prompts;

import java.util.Scanner;

import com.revature.daos.DBConnectionDao;
import com.revature.daos.UserDao;
import com.revature.user.User;

public class LoginPrompt implements Prompt {
	private Scanner s = new Scanner(System.in);
	DBConnectionDao dbDao = new DBConnectionDao();
	UserDao user = UserDao.currentImplementation;

	@Override
	public Prompt run() {
		System.out.println("Welcome to the Banking App");
		System.out.println("Please log in!");
		System.out.println();
		
		// login
		System.out.print("Username: ");
		String username = s.nextLine();
		System.out.print("Password: ");
		String password = s.nextLine();
		
		if (dbDao.findByUsernameAndPassword(username, password))
		{
			// if credentials are good, proceed. Otherwise, try again!
			if ("Admin".equals(user.getRole()))
			{
				return new AdminPrompt();
			}
			else if (user.getRole().equals("User"))
			{
				return new MainMenuPrompt();
			}
			else 
			{
				System.out.println("Invalid login, try again!");
				return new LoginPrompt();
			}
		}
		return new LoginPrompt();
	}
}
