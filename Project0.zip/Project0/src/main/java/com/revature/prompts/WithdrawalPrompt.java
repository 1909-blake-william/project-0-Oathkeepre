package com.revature.prompts;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.revature.daos.AccountsDao;
import com.revature.daos.DBConnectionDao;
import com.revature.daos.UserDao;
import com.revature.user.Accounts;

public class WithdrawalPrompt implements Prompt {
	private Scanner s = new Scanner(System.in);
	DBConnectionDao dbDao = new DBConnectionDao();
	UserDao user = UserDao.currentImplementation;
	AccountsDao accs = AccountsDao.currentImplementation;

	@Override
	public Prompt run() 
	{
		System.out.println("Please type in account id for which you'd like to make a withdrawal: ");
		dbDao.displayAllAccounts(user.getUserId());
		System.out.println();
		System.out.print("Which account?: ");
		int choice = s.nextInt();
		s.nextLine();
		List<Accounts> accounts = new ArrayList<>();
		accounts = accs.getList();
		boolean thisWorks = false;

		while (thisWorks == false) 
		{
			for (Accounts a : accounts) 
			{
				if (choice == a.getAccountId()) 
				{
					dbDao.makeWithdrawal(choice);
					thisWorks = true;
				}
			}
			if(!thisWorks)
			{
				System.out.println("Please input a valid account number");
				dbDao.displayAllAccounts(user.getUserId());
				System.out.print("Which account?: ");
				choice = s.nextInt();
				s.nextLine();
			}
		}

		return new MainMenuPrompt();
	}

}
