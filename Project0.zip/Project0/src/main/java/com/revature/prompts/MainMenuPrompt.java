package com.revature.prompts;

import java.util.Scanner;

import com.revature.daos.DBConnectionDao;

public class MainMenuPrompt implements Prompt 
{
	private Scanner s = new Scanner(System.in);
	DBConnectionDao dbDao = new DBConnectionDao();

	public Prompt run() 
	{
		String selection = " ";
		while (selection != "5") 
		{
			// begin prompts
			System.out.println();
			System.out.println("Enter 1 to view accounts and details");
			System.out.println("Enter 2 to add/remove accounts");
			System.out.println("Enter 3 to make a deposit");
			System.out.println("Enter 4 to make a withdrawal");
			System.out.println("Enter 5 to view transactions by account");
			System.out.println("Enter 6 to log out");

			selection = s.nextLine();

			switch (selection) 
			{
			case "1":
				return new ViewAccountsPrompt();
			case "2":
				return new AccountManagementPrompt();
			case "3":
				return new DepositPrompt();
			case "4":
				return new WithdrawalPrompt();
			case "5":
				return new TransactionPrompt();
			case "6":
				System.out.println("Have a great day!");
				System.out.println();
				return new LoginPrompt();
			default:
				System.out.println("Invalid selection, try again!");
				break;
			}
		}
		return new LoginPrompt();
	}
}
