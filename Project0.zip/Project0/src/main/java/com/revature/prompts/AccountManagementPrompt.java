package com.revature.prompts;

import java.util.Scanner;

import com.revature.daos.DBConnectionDao;
import com.revature.daos.UserDao;

public class AccountManagementPrompt implements Prompt
{
	private Scanner s = new Scanner(System.in);
	DBConnectionDao dbDao = new DBConnectionDao();
	UserDao user = UserDao.currentImplementation;
	
	
	@Override
	public Prompt run()
	{
		System.out.println("Please choose an option");
		System.out.println("Enter 1 to add an account");
		System.out.println("Enter 2 to delete an account");
		System.out.println("Enter 3 to go back to main menu");
		System.out.println("Your choice?: ");
		String choice = s.nextLine();
		
		switch (choice)
		{
			case "1":
				dbDao.addAccount();
				break;
			case "2":
				dbDao.deleteAccount(user.getUserId());
				break;
			case "3":
				return new MainMenuPrompt();
			default:
				System.out.println("Invalid entry, try again!");
				return new AccountManagementPrompt();
		}
		return new AccountManagementPrompt();
	}
}
