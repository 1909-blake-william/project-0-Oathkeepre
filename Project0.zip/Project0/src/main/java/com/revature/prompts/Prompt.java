package com.revature.prompts;

public interface Prompt 
{
	Prompt run();
}
