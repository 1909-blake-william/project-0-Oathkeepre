package com.revature.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionsUtil 
{
	public static Connection getConnection() throws SQLException 
	{
		String url = System.getenv("POKEMON_DB_URL");
		String username = System.getenv("PROJECT_0_USER");
		String password = System.getenv("PROJECT_0_PASSWORD");
		return DriverManager.getConnection(url, username, password);
	}
}
