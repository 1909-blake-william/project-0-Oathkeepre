package com.revature.daos;

import com.revature.user.User;

public class UserDaoImpl implements UserDao
{
	User user;
	
	@Override
	public void createUser(int userId, String username, String password, String role) 
	{
		user = new User(userId, username, role);
	}

	@Override
	public int getUserId() 
	{
		return user.getUserId();
	}

	@Override
	public String getUsername() 
	{
		return user.getName();
	}

	@Override
	public String getRole() 
	{
		return user.getRole();
	}
}
