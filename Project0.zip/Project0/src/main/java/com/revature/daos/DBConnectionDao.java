package com.revature.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Scanner;

import com.revature.utils.ConnectionsUtil;

public class DBConnectionDao 
{
	Timestamp ts;
	AccountsDao accounts = AccountsDao.currentImplementation;
	UserDao user = UserDao.currentImplementation;
	public boolean findByUsernameAndPassword(String username, String password)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "SELECT * FROM people WHERE username = ? AND password = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if (rs.next())
			{
				int id = rs.getInt("user_id");
				String role = rs.getString("role");
				user.createUser(id, username, password, role);
				return true;
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return false;
	}
	public boolean isAdmin(String username, String password)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "SELECT * FROM people WHERE username = ? AND password = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())
			{
				System.out.println(rs.getString("role"));
				if ("Admin".equals(rs.getString("role"))) 
				{
					return true;
				}
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return false;
	}
	public void displayAllAccounts(int userId)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "SELECT * FROM accounts WHERE u_id = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				System.out.print(rs.getInt("acc_id"));
				System.out.print(", ");
				System.out.print(rs.getString("account_type"));
				System.out.print(", ");
				System.out.println(rs.getFloat("balance"));
				int accId = rs.getInt("acc_id");
				String type = rs.getString("account_type");
				float balance = rs.getFloat("balance");
				accounts.createAccount(accId, userId, type, balance);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void adminDisplayAllAccounts()
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "Select people.username, accounts.account_type, accounts.balance From accounts " + 
						 "Inner Join people " + 
						 "On accounts.u_id = people.user_id Order By people.username";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				System.out.print(rs.getString("username"));
				System.out.print(", ");
				System.out.print(rs.getString("account_type"));
				System.out.print(", ");
				System.out.println(rs.getFloat("balance"));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void adminDisplayAllUsers()
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "Select people.user_id, people.username, people.role From people " +
						 "Order By user_id";
			PreparedStatement ps = c.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			while (rs.next())
			{
				System.out.print(rs.getString("user_id"));
				System.out.print(", ");
				System.out.print(rs.getString("username"));
				System.out.print(", ");
				System.out.println(rs.getString("role"));
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void addAccount()
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			Scanner sc = new Scanner(System.in);
			String accType = "";
			float balance = 0;
			
			
			//type of account
			System.out.print("What type of account is this?: ");
			accType = sc.nextLine();
			
			//starting balance
			System.out.print("How much money is there to start?: ");
			balance = sc.nextFloat();
			sc.nextLine();
			
			//insert into table and update it
			String sql = "INSERT INTO accounts Values(accounts_seq.nextval, ?, ?, ?)";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, user.getUserId());
			ps.setString(2, accType);
			ps.setFloat(3, balance);
			ps.executeUpdate();
			System.out.println("Account added!");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void deleteAccount(int id)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			Scanner sc = new Scanner(System.in);
			
			String sql = "SELECT * FROM accounts WHERE u_id = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) 
			{
				System.out.print(rs.getInt("acc_id"));
				System.out.print(", ");
				System.out.print(rs.getInt("u_id"));
				System.out.print(", ");
				System.out.print(rs.getString("account_type"));
				System.out.print(", ");
				System.out.println(rs.getFloat("balance"));
			}
			System.out.print("Specify (by account id) which account you want to delete: ");
			int acc = sc.nextInt();
			
			String sql2 = "DELETE FROM accounts WHERE acc_id = ?";
			PreparedStatement ps2 = c.prepareStatement(sql2);
			ps2.setInt(1, acc);
			ps2.executeUpdate();
			System.out.println("Account deleted!");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void makeDeposit(int acc_id)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			Scanner s = new Scanner(System.in);
			String sql = "SELECT * FROM accounts WHERE acc_id = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, acc_id);
			ResultSet rs = ps.executeQuery();
			float balance = 0f;
			while (rs.next())
			{
				balance = (rs.getFloat("balance"));
			}
			
			System.out.print("How much would you like to deposit?: ");
			float amount = s.nextFloat();
			s.nextLine();
			
			String dep = "UPDATE accounts SET balance = ? WHERE acc_id = ?";
			PreparedStatement ps2 = c.prepareStatement(dep);
			System.out.println(amount);
			float total = balance + amount;
			ps2.setFloat(1, total);
			ps2.setInt(2, acc_id);
			
			ps2.executeUpdate();
			ts = new Timestamp(System.currentTimeMillis());
			
			String depositEntry = "INSERT INTO transactions VALUES (transactions_seq.nextval, ?, ?, ?, ?, ?)";
			PreparedStatement depositPS = c.prepareStatement(depositEntry);
			System.out.println(amount);
			depositPS.setInt(1, user.getUserId());
			depositPS.setInt(2, acc_id);
			depositPS.setFloat(3, amount);
			depositPS.setString(4, "Deposit");
			depositPS.setTimestamp(5, ts);
			depositPS.executeUpdate();
			System.out.println("Deposit made!");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void makeWithdrawal(int acc_id)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			Scanner s = new Scanner(System.in);
			String sql = "SELECT * FROM accounts WHERE acc_id = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, acc_id);
			ResultSet rs = ps.executeQuery();
			float balance = 0f;
			while (rs.next())
			{
				balance = rs.getFloat("balance");
			}
			
			System.out.println("How much would you like to withdrawl?: ");
			float amount = s.nextFloat();
			s.nextLine();
			
			if (amount > balance)
			{
				System.out.println("Cannot exceed balance amount! Try again.");
				while (amount > balance)
				{
					System.out.println("How much would you like to withdrawl?: ");
					amount = s.nextFloat();
				}
			}
			
			String dep = "UPDATE accounts SET balance = ? WHERE acc_id = ?";
			PreparedStatement ps2 = c.prepareStatement(dep);
			System.out.println(amount);
			float total = balance - amount;
			ps2.setFloat(1, total);
			ps2.setInt(2, acc_id);
			
			ps2.executeUpdate();
			ts = new Timestamp(System.currentTimeMillis());
			String withdrawEntry = "INSERT INTO transactions VALUES (transactions_seq.nextval, ?, ?, ?, ?, ?)";
			PreparedStatement withdrawPS = c.prepareStatement(withdrawEntry);
			System.out.println(amount);
			withdrawPS.setInt(1, user.getUserId());
			withdrawPS.setInt(2, acc_id);
			withdrawPS.setFloat(3, amount);
			withdrawPS.setString(4, "Withdrawal");
			withdrawPS.setTimestamp(5, ts);
			withdrawPS.executeUpdate();
			System.out.println("Withdrawal made!");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	public void displayTransactions(int user_id)
	{
		try (Connection c = ConnectionsUtil.getConnection())
		{
			String sql = "SELECT * FROM transactions WHERE u_id = ?";
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setInt(1, user_id);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())
			{
				int trans_id = rs.getInt("transaction_id");
				int userId = rs.getInt("u_id");
				int acctId = rs.getInt("a_id");
				float balance = rs.getFloat("amount");
				String type = rs.getString("trans_type");
				String time = rs.getString("trans_date");
				System.out.println("Transaction ID: " + trans_id);
				System.out.println("User ID: " + userId);
				System.out.println("Account ID: " + acctId);
				System.out.println("Amount: " + balance);
				System.out.println("Transaction Type: " + type);
				System.out.println("Transaction Time: " + time);
				System.out.println();
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
}
