package com.revature.daos;

public interface UserDao 
{
	UserDao currentImplementation = new UserDaoImpl();
	void createUser(int userId, String username, String password, String role);
	int getUserId();
	String getUsername();
	String getRole();
}
