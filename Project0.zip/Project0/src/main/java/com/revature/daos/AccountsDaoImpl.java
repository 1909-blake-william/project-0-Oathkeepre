package com.revature.daos;

import java.util.ArrayList;
import java.util.List;

import com.revature.user.Accounts;

public class AccountsDaoImpl implements AccountsDao
{
	Accounts account;
	List<Accounts> accs = new ArrayList<>();
	
	@Override
	public void createAccount(int accountId, int userId, String type, float balance) 
	{
		account = new Accounts(accountId, userId, type, balance);
		accs.add(account);
	}
	@Override
	public List<Accounts> getList()
	{
		return accs;
	}
}
