package com.revature.daos;

import java.util.List;

import com.revature.user.Accounts;

public interface AccountsDao 
{
	AccountsDao currentImplementation = new AccountsDaoImpl();
	void createAccount(int accountId, int userId, String type, float balance);
	List<Accounts> getList();
	
}
