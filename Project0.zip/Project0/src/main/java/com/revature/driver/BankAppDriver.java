package com.revature.driver;

import com.revature.prompts.LoginPrompt;
import com.revature.prompts.Prompt;

public class BankAppDriver 
{
	public static void main(String[] args) 
	{
		Prompt curr = new LoginPrompt();
		
		while (true)
		{
			curr = curr.run();
		}
	}
}
