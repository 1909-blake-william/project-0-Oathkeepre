Insert Into accounts
Values(ACCOUNTS_SEQ.nextval, 44, 'Credit', 1000.00);

Delete From accounts
Where acc_id = 16;

